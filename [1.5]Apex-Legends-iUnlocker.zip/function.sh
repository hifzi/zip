#!/system/bin/sh
#MODPATH=/data/adb/modules_update/Apex-Legends-iUnlocker
#sysbin=$MODPATH/system/bin
MDIR=/data/adb
cout() { printf "$1"; }
dezip() { unzip -qo "$1" "$2" -d "$3" | echo "ZIPFILE: [☄: $2)"; }
RNM() { mv "$sysbin/$1" "$sysbin/$2" | echo "Renamed to: $2"; }
progress() { sleep "$@"; echo " + D: $(date +%d/%y/%m)" | head -n 1; }
