#!/system/bin/sh
MODDIR=${0%/*}
#.$MODDIR/goodbye