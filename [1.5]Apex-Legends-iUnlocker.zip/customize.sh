# Installer
FS=$(date +"%s")
SKIPUNZIP=1
TERMUX=yes
CALLBACK=2
unzip -qo "$ZIPFILE" "function.sh" "$TMPDIR"
. "$TMPDIR/function.sh"
dezip "$ZIPFILE" "system/*" "$MODPATH"
dezip "$ZIPFILE" "module.prop" "$MODPATH"
dezip "$ZIPFILE" "service.sh" "$MODPATH"
#dezip "$ZIPFILE" "goodbye" "$MODPATH"
dezip "$ZIPFILE" "post-fs-data.sh" "$MODPATH"
dezip "$ZIPFILE" "LICENSE" "$MODPATH"
dezip "$ZIPFILE" "iUnlocker" "$MODPATH"
dezip "$ZIPFILE" "iUnlocker-fuse" "$MODPATH"
dezip "$ZIPFILE" "iUnlocker-libraries.so/*" "$MDIR"
dezip "$ZIPFILE" "uninstall.sh" "$MODPATH"
ln -s "$MDIR/iUnlocker-libraries.so/libV9y_7V2.so" "$MDIR/iUnlocker-libraries.so/libV9y_7V2.so.1.2.0.9.2.4"
chmod 777 "$MDIR/iUnlocker-libraries.so/*"
chmod 777 $MODPATH/*