#!/system/bin/sh
ui_print " "
ui_print "*****************************************************"
ui_print "  " 
ui_print "  × Graphics Unlocker for APEX LEGENDS MOBILE      "
sleep 0.4
ui_print "  " 
ui_print "  × Everything Unlocked        "
sleep 0.3
ui_print "  " 
ui_print "  × Credits: ASMODEUS TG:@iWillBanU                              "
sleep 0.2  
ui_print "  " 
ui_print "  × Its Safe, But Still Use At Your Own Risk xD      "
ui_print "  " 
ui_print "*****************************************************"
sleep 0.1  

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/config 0 0 0755 0755
  set_perm $MODPATH/em/* 0 2000 0755 0644
}

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'em/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
postfs=$TMPDIR/post-fs-data.sh
. $TMPDIR/functions.sh

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases


